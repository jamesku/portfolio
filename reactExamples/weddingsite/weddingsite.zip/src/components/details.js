import React from 'react';

export default class Details extends React.Component {
    constructor(props){
        super(props);
        
    }  
    render() {
            
    return (        
        <div>  
            <h4>Mass</h4>
            <h3>Our Lady of Guadalupe</h3>
            <h4><a href ="https://www.google.com/maps/place/1206+E+9th+St,+Austin,+TX+78702/@30.2671191,-97.7296921,17z/data=!4m13!1m7!3m6!1s0x8644b5ba5cf3bcd7:0x76ad782a98491852!2s1206+E+9th+St,+Austin,+TX+78702!3b1!8m2!3d30.2671191!4d-97.7275034!3m4!1s0x8644b5ba5cf3bcd7:0x76ad782a98491852!8m2!3d30.2671191!4d-97.7275034">1206 E 9th Street</a></h4>
     <br/>
            <h4>Reception</h4>
            <h3>Charles Johnson House</h3>
            <h4><a href ="https://www.google.com/maps/place/The+American+Legion-+Charles+Johnson+House/@30.2766256,-97.7735162,17z/data=!3m1!4b1!4m5!3m4!1s0x8644b54705e158b5:0x5cff549772f27210!8m2!3d30.2766256!4d-97.7713275">404 Atlanta Street</a></h4>
            <br />
            <br />
         <h4>Austin, Texas</h4>
        </div>
        );
    }
}
